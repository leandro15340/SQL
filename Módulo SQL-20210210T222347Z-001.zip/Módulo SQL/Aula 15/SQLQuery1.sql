select * from DimProduct
select ProductKey,ProductName,BrandName, UnitPrice from DimProduct